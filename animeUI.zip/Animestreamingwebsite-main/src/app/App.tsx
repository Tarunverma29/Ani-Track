import { useState, useMemo, useCallback, useEffect } from "react";
import { TuiTopBar, TuiView } from "./components/TuiTopBar";
import { TuiSidebar } from "./components/TuiSidebar";
import { TuiList } from "./components/TuiList";
import { TuiDetail } from "./components/TuiDetail";
import { TuiStats } from "./components/TuiStats";
import { TuiDiscover } from "./components/TuiDiscover";
import { TuiStatusBar } from "./components/TuiStatusBar";
import {
  TrackedAnime,
  WatchStatus,
  library as initialLibrary,
  ALL_STATUSES,
} from "./components/trackingData";

const MONO = "'JetBrains Mono', monospace";

export default function App() {
  const [view, setView] = useState<TuiView>("library");
  const [activeStatus, setActiveStatus] = useState<WatchStatus | "all">("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [library, setLibrary] = useState<TrackedAnime[]>(initialLibrary);
  const [statusMsg, setStatusMsg] = useState("");

  // Keyboard navigation
  useEffect(() => {
    function handleKey(e: KeyboardEvent) {
      // Don't hijack when typing in inputs
      if (e.target instanceof HTMLInputElement) return;

      if (e.key === "1") setView("library");
      if (e.key === "2") { setView("discover"); setSelectedId(null); }
      if (e.key === "3") { setView("stats"); setSelectedId(null); }
      if (e.key === "Escape") setSelectedId(null);

      if (view === "library") {
        const filtered = getFiltered();
        const idx = filtered.findIndex((a) => a.id === selectedId);
        if (e.key === "j" || e.key === "ArrowDown") {
          const next = filtered[idx + 1];
          if (next) setSelectedId(next.id);
          else if (filtered.length > 0) setSelectedId(filtered[0].id);
        }
        if (e.key === "k" || e.key === "ArrowUp") {
          const prev = filtered[idx - 1];
          if (prev) setSelectedId(prev.id);
          else if (filtered.length > 0) setSelectedId(filtered[filtered.length - 1].id);
        }
        if ((e.key === "w") && !e.ctrlKey) setActiveStatus("watching");
        if (e.key === "c") setActiveStatus("completed");
        if (e.key === "p") setActiveStatus("planning");
        if (e.key === "h") setActiveStatus("on-hold");
        if (e.key === "d") setActiveStatus("dropped");
        if (e.key === "a") setActiveStatus("all");
      }
    }
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [view, selectedId, activeStatus, library, searchQuery]);

  function getFiltered() {
    return library.filter((a) => {
      const matchStatus = activeStatus === "all" || a.status === activeStatus;
      const q = searchQuery.toLowerCase();
      const matchQ = !q || a.title.toLowerCase().includes(q) || a.titleJp.includes(q) || a.studio.toLowerCase().includes(q);
      return matchStatus && matchQ;
    });
  }

  const filtered = useMemo(getFiltered, [library, activeStatus, searchQuery]);
  const selected = library.find((a) => a.id === selectedId) ?? null;

  function flash(msg: string) {
    setStatusMsg(msg);
    setTimeout(() => setStatusMsg(""), 2000);
  }

  const handleUpdateEp = useCallback((id: number, delta: number) => {
    setLibrary((prev) => prev.map((a) => {
      if (a.id !== id) return a;
      const next = Math.max(0, Math.min(a.totalEpisodes, a.episodesWatched + delta));
      const newStatus: WatchStatus = next >= a.totalEpisodes ? "completed" : a.status === "planning" ? "watching" : a.status;
      flash(delta > 0 ? `+1 ep — ${a.title} (${next}/${a.totalEpisodes})` : `-1 ep — ${a.title} (${next}/${a.totalEpisodes})`);
      return { ...a, episodesWatched: next, status: newStatus, lastUpdated: "just now" };
    }));
  }, []);

  const handleStatusChange = useCallback((id: number, status: WatchStatus) => {
    setLibrary((prev) => prev.map((a) => {
      if (a.id !== id) return a;
      const ep = status === "completed" ? a.totalEpisodes : a.episodesWatched;
      flash(`status → ${status.toUpperCase()}`);
      return { ...a, status, episodesWatched: ep, lastUpdated: "just now" };
    }));
  }, []);

  const handleScoreChange = useCallback((id: number, score: number | null) => {
    setLibrary((prev) => prev.map((a) => {
      if (a.id !== id) return a;
      flash(score !== null ? `scored ${score}/10` : "score cleared");
      return { ...a, userScore: score, lastUpdated: "just now" };
    }));
  }, []);

  const handleAddToLibrary = useCallback((item: any, status: WatchStatus) => {
    if (library.some((a) => a.id === item.id)) return;
    const entry: TrackedAnime = {
      ...item,
      episodesWatched: 0,
      status,
      userScore: null,
      lastUpdated: "just now",
      addedDate: new Date().toISOString().split("T")[0],
      banner: item.image,
      duration: "24 min",
    };
    setLibrary((prev) => [...prev, entry]);
    flash(`added: ${item.title}`);
    setView("library");
    setSelectedId(item.id);
  }, [library]);

  return (
    <div
      className="flex flex-col overflow-hidden"
      style={{
        height: "100vh",
        background: "#090b0e",
        fontFamily: MONO,
        color: "#8a96a4",
        fontSize: 13,
      }}
    >
      {/* Top bar */}
      <TuiTopBar
        view={view}
        onViewChange={(v) => { setView(v); setSelectedId(null); }}
        searchQuery={searchQuery}
        onSearch={setSearchQuery}
        totalInLib={library.length}
      />

      {/* Main layout */}
      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar — only on library view */}
        {view === "library" && (
          <TuiSidebar
            library={library}
            activeStatus={activeStatus}
            onStatusChange={setActiveStatus}
            selectedId={selectedId}
          />
        )}

        {/* Main content area */}
        <div className="flex flex-1 overflow-hidden">
          {view === "library" && (
            <>
              <TuiList
                items={filtered}
                selectedId={selectedId}
                onSelect={(id) => setSelectedId(selectedId === id ? null : id)}
                onUpdateEp={handleUpdateEp}
              />
              {selected && (
                <TuiDetail
                  anime={selected}
                  onClose={() => setSelectedId(null)}
                  onStatusChange={handleStatusChange}
                  onScoreChange={handleScoreChange}
                  onEpChange={handleUpdateEp}
                />
              )}
            </>
          )}

          {view === "discover" && (
            <TuiDiscover
              library={library}
              onAddToLibrary={handleAddToLibrary}
            />
          )}

          {view === "stats" && (
            <TuiStats library={library} />
          )}
        </div>
      </div>

      {/* Status bar */}
      <TuiStatusBar
        view={view}
        activeStatus={activeStatus}
        filteredCount={filtered.length}
        selectedTitle={selected?.title}
        message={statusMsg}
      />
    </div>
  );
}
