import { WatchStatus, TrackedAnime, ALL_STATUSES, STATUS_COLORS } from "./trackingData";

interface TuiSidebarProps {
  library: TrackedAnime[];
  activeStatus: WatchStatus | "all";
  onStatusChange: (s: WatchStatus | "all") => void;
  selectedId: number | null;
}

const MONO = "'JetBrains Mono', monospace";

const STATUS_JP: Record<WatchStatus | "all", string> = {
  all: "全て",
  watching: "視聴中",
  completed: "完了",
  planning: "計画中",
  "on-hold": "保留",
  dropped: "中断",
};

const STATUS_KEYS: Record<WatchStatus | "all", string> = {
  all: "a",
  watching: "w",
  completed: "c",
  planning: "p",
  "on-hold": "h",
  dropped: "d",
};

export function TuiSidebar({ library, activeStatus, onStatusChange }: TuiSidebarProps) {
  const countFor = (s: WatchStatus | "all") =>
    s === "all" ? library.length : library.filter((a) => a.status === s).length;

  const totalEp = library.reduce((n, a) => n + a.episodesWatched, 0);
  const totalHours = Math.floor(library.reduce((n, a) => {
    const m = parseInt(a.duration) || 24;
    return n + a.episodesWatched * m;
  }, 0) / 60);

  const items: (WatchStatus | "all")[] = ["all", ...ALL_STATUSES];

  return (
    <div
      className="flex-shrink-0 flex flex-col border-r overflow-hidden"
      style={{ width: 192, borderColor: "rgba(255,255,255,0.07)", background: "#090b0e", fontFamily: MONO }}
    >
      {/* Section header */}
      <div
        className="px-3 py-2 border-b flex items-center gap-2"
        style={{ borderColor: "rgba(255,255,255,0.07)" }}
      >
        <span style={{ color: "#2a3545", fontSize: "0.6rem" }}>┌─</span>
        <span style={{ color: "#3d4e62", fontSize: "0.6rem", letterSpacing: "0.1em" }}>STATUS FILTER</span>
      </div>

      {/* Status list */}
      <div className="flex-1 py-1">
        {items.map((s) => {
          const active = activeStatus === s;
          const count = countFor(s);
          const color = s === "all" ? "#8a96a4" : STATUS_COLORS[s as WatchStatus];
          return (
            <button
              key={s}
              onClick={() => onStatusChange(s)}
              className="w-full flex items-center justify-between px-3 py-1.5 relative"
              style={{
                background: active ? "#111520" : "transparent",
                cursor: "pointer",
                fontFamily: MONO,
              }}
            >
              {active && (
                <span
                  className="absolute left-0 top-0 bottom-0 w-px"
                  style={{ background: "#b83040" }}
                />
              )}
              <div className="flex items-center gap-2">
                <span style={{ color: active ? "#b83040" : "#2a3545", fontSize: "0.58rem" }}>
                  {active ? "▶" : " "}
                </span>
                <span
                  style={{
                    color: active ? "#c8d0da" : color,
                    fontSize: "0.67rem",
                    letterSpacing: "0.06em",
                    fontWeight: active ? 600 : 400,
                  }}
                >
                  {s === "all" ? "ALL" : s.toUpperCase()}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span style={{ color: "#3d4e62", fontSize: "0.58rem" }}>
                  [{STATUS_KEYS[s]}]
                </span>
                <span
                  className="tabular-nums"
                  style={{ color: count > 0 ? color : "#2a3545", fontSize: "0.65rem", minWidth: 14, textAlign: "right" }}
                >
                  {count}
                </span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Divider */}
      <div className="border-t px-3 py-1.5" style={{ borderColor: "rgba(255,255,255,0.07)" }}>
        <span style={{ color: "#2a3545", fontSize: "0.6rem" }}>── TOTALS</span>
      </div>

      {/* Summary stats */}
      <div className="px-3 py-2 flex flex-col gap-2 border-t" style={{ borderColor: "rgba(255,255,255,0.07)" }}>
        {[
          { label: "entries", value: library.length },
          { label: "episodes", value: totalEp },
          { label: "hours", value: totalHours },
        ].map(({ label, value }) => (
          <div key={label} className="flex justify-between items-baseline">
            <span style={{ color: "#3d4e62", fontSize: "0.6rem", letterSpacing: "0.06em" }}>{label}</span>
            <span className="tabular-nums" style={{ color: "#8a96a4", fontSize: "0.68rem", fontWeight: 600 }}>{value}</span>
          </div>
        ))}
      </div>

      {/* JP label at bottom */}
      <div
        className="px-3 py-2 border-t"
        style={{ borderColor: "rgba(255,255,255,0.07)" }}
      >
        <div style={{ fontFamily: "'Noto Sans JP', sans-serif", fontSize: "0.75rem", color: "#1e2a38", letterSpacing: "0.08em" }}>
          アニメ追跡
        </div>
      </div>
    </div>
  );
}
