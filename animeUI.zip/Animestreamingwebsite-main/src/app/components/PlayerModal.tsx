import { useEffect, useRef, useState } from "react";
import { X, Play, Pause, Volume2, VolumeX, Maximize2, SkipForward, ChevronLeft } from "lucide-react";
import { Anime } from "./animeData";

interface PlayerModalProps {
  anime: Anime;
  onClose: () => void;
}

export function PlayerModal({ anime, onClose }: PlayerModalProps) {
  const [playing, setPlaying] = useState(true);
  const [muted, setMuted] = useState(false);
  const [progress, setProgress] = useState(anime.progress ?? 0);
  const [showControls, setShowControls] = useState(true);
  const timerRef = useRef<ReturnType<typeof setTimeout>>();

  useEffect(() => {
    document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = ""; };
  }, []);

  function resetControlsTimer() {
    setShowControls(true);
    clearTimeout(timerRef.current);
    timerRef.current = setTimeout(() => setShowControls(false), 3000);
  }

  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;
    if (playing && progress < 100) {
      interval = setInterval(() => setProgress((p) => Math.min(p + 0.1, 100)), 200);
    }
    return () => clearInterval(interval);
  }, [playing, progress]);

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center" style={{ background: "rgba(0,0,0,0.95)" }}>
      {/* Fake player area */}
      <div
        className="relative w-full max-w-5xl mx-4 rounded-lg overflow-hidden"
        style={{ aspectRatio: "16/9", background: "#000", cursor: showControls ? "default" : "none" }}
        onMouseMove={resetControlsTimer}
        onClick={() => setPlaying((p) => !p)}
      >
        {/* Fake video background */}
        <img
          src={anime.banner || anime.image}
          alt={anime.title}
          className="w-full h-full object-cover"
          style={{ filter: "brightness(0.35) saturate(0.6)" }}
        />

        {/* Cinematic bars */}
        <div className="absolute top-0 left-0 right-0 h-10" style={{ background: "#000" }} />
        <div className="absolute bottom-0 left-0 right-0 h-10" style={{ background: "#000" }} />

        {/* Center play indicator */}
        {!playing && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div
              className="w-20 h-20 rounded-full flex items-center justify-center"
              style={{ background: "rgba(192,24,43,0.85)", backdropFilter: "blur(8px)" }}
            >
              <Play size={36} fill="white" className="text-white ml-1" />
            </div>
          </div>
        )}

        {/* Title overlay */}
        <div
          className="absolute top-12 left-6 transition-opacity duration-300"
          style={{ opacity: showControls ? 1 : 0 }}
        >
          <p className="text-white text-sm" style={{ fontFamily: "'Noto Sans JP', sans-serif", color: "#c8991a", fontSize: "0.7rem" }}>
            {anime.titleJp}
          </p>
          <p className="text-white" style={{ fontFamily: "'Cinzel', serif", fontWeight: 700, fontSize: "1.2rem" }}>
            {anime.title}
          </p>
          <p style={{ fontFamily: "'DM Sans', sans-serif", fontSize: "0.75rem", color: "#7a8499" }}>
            Episode 1 — The Beginning
          </p>
        </div>

        {/* Controls overlay */}
        <div
          className="absolute bottom-10 left-0 right-0 px-6 transition-opacity duration-300"
          style={{ opacity: showControls ? 1 : 0 }}
          onClick={(e) => e.stopPropagation()}
        >
          {/* Progress bar */}
          <div className="relative mb-3 cursor-pointer group" style={{ height: 4 }}>
            <div className="absolute inset-0 rounded-full" style={{ background: "rgba(255,255,255,0.2)" }} />
            <div
              className="absolute left-0 top-0 h-full rounded-full"
              style={{ width: `${progress}%`, background: "#c0182b" }}
            />
            <div
              className="absolute top-1/2 -translate-y-1/2 w-3 h-3 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
              style={{ left: `${progress}%`, transform: `translateX(-50%) translateY(-50%)`, background: "#c0182b" }}
            />
          </div>

          {/* Control buttons */}
          <div className="flex items-center gap-4">
            <button
              onClick={() => setPlaying((p) => !p)}
              className="p-2 rounded-full transition hover:scale-110"
              style={{ color: "#fff" }}
            >
              {playing ? <Pause size={20} /> : <Play size={20} fill="white" />}
            </button>
            <button className="p-2 rounded-full transition hover:scale-110" style={{ color: "#fff" }}>
              <SkipForward size={18} />
            </button>
            <button
              onClick={() => setMuted((m) => !m)}
              className="p-2 rounded-full transition hover:scale-110"
              style={{ color: "#fff" }}
            >
              {muted ? <VolumeX size={18} /> : <Volume2 size={18} />}
            </button>
            <span className="text-xs ml-1" style={{ fontFamily: "'DM Sans', sans-serif", color: "#7a8499" }}>
              {Math.floor(progress / 100 * 24)}:{String(Math.floor((progress / 100 * 24 * 60) % 60)).padStart(2, "0")} / 24:00
            </span>
            <div className="flex-1" />
            <button className="p-2 rounded-full transition hover:scale-110" style={{ color: "#fff" }}>
              <Maximize2 size={18} />
            </button>
          </div>
        </div>

        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-12 right-4 p-2 rounded-full transition hover:scale-110"
          style={{
            background: "rgba(7,9,15,0.8)",
            color: "#e8eaf0",
            opacity: showControls ? 1 : 0,
            transition: "opacity 0.3s",
          }}
        >
          <X size={20} />
        </button>
      </div>

      {/* Anime info panel below */}
      <button
        onClick={onClose}
        className="absolute top-6 left-6 flex items-center gap-2 transition hover:opacity-80"
        style={{ color: "#c8cdd8", fontFamily: "'DM Sans', sans-serif", fontSize: "0.85rem" }}
      >
        <ChevronLeft size={18} />
        Back to Browse
      </button>
    </div>
  );
}
