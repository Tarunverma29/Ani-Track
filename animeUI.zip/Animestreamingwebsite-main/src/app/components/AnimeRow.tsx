import { useRef } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Anime } from "./animeData";
import { AnimeCard } from "./AnimeCard";

interface AnimeRowProps {
  title: string;
  titleJp?: string;
  anime: Anime[];
  onPlay: (anime: Anime) => void;
  showProgress?: boolean;
  cardSize?: "sm" | "md" | "lg";
}

export function AnimeRow({ title, titleJp, anime, onPlay, showProgress = false, cardSize = "md" }: AnimeRowProps) {
  const rowRef = useRef<HTMLDivElement>(null);

  function scroll(dir: "left" | "right") {
    if (!rowRef.current) return;
    const amount = rowRef.current.clientWidth * 0.7;
    rowRef.current.scrollBy({ left: dir === "left" ? -amount : amount, behavior: "smooth" });
  }

  return (
    <section className="mb-12">
      {/* Section header */}
      <div className="flex items-center justify-between mb-5 px-8 md:px-16">
        <div className="flex items-center gap-4">
          <div className="w-1 h-6 rounded-full" style={{ background: "#c0182b" }} />
          <div>
            <h2
              className="text-white"
              style={{ fontFamily: "'Cinzel', serif", fontWeight: 700, fontSize: "1.1rem", letterSpacing: "0.05em" }}
            >
              {title}
            </h2>
            {titleJp && (
              <p style={{ fontFamily: "'Noto Sans JP', sans-serif", fontSize: "0.7rem", color: "#7a8499" }}>
                {titleJp}
              </p>
            )}
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => scroll("left")}
            className="p-1.5 rounded-full transition hover:scale-110"
            style={{ background: "rgba(255,255,255,0.08)", color: "#c8cdd8", border: "1px solid rgba(255,255,255,0.1)" }}
          >
            <ChevronLeft size={16} />
          </button>
          <button
            onClick={() => scroll("right")}
            className="p-1.5 rounded-full transition hover:scale-110"
            style={{ background: "rgba(255,255,255,0.08)", color: "#c8cdd8", border: "1px solid rgba(255,255,255,0.1)" }}
          >
            <ChevronRight size={16} />
          </button>
        </div>
      </div>

      {/* Scrollable row */}
      <div
        ref={rowRef}
        className="flex gap-4 overflow-x-auto px-8 md:px-16 pb-4"
        style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
      >
        {anime.map((a) => (
          <AnimeCard key={a.id} anime={a} onPlay={onPlay} showProgress={showProgress} size={cardSize} />
        ))}
      </div>
    </section>
  );
}
