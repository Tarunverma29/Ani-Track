import { useState } from "react";

export type TuiView = "library" | "discover" | "stats";

interface TuiTopBarProps {
  view: TuiView;
  onViewChange: (v: TuiView) => void;
  searchQuery: string;
  onSearch: (q: string) => void;
  totalInLib: number;
}

const MONO = "'JetBrains Mono', monospace";

export function TuiTopBar({ view, onViewChange, searchQuery, onSearch, totalInLib }: TuiTopBarProps) {
  const [searchFocused, setSearchFocused] = useState(false);

  const tabs: { id: TuiView; label: string; key: string }[] = [
    { id: "library", label: "LIBRARY", key: "1" },
    { id: "discover", label: "DISCOVER", key: "2" },
    { id: "stats", label: "STATS", key: "3" },
  ];

  return (
    <div
      className="flex-shrink-0 flex items-stretch border-b"
      style={{
        height: 36,
        borderColor: "rgba(255,255,255,0.07)",
        background: "#090b0e",
        fontFamily: MONO,
      }}
    >
      {/* Brand */}
      <div
        className="flex items-center px-4 border-r gap-2 flex-shrink-0"
        style={{ borderColor: "rgba(255,255,255,0.07)" }}
      >
        <span style={{ color: "#b83040", fontSize: "0.7rem", fontWeight: 700, letterSpacing: "0.15em" }}>
          ■
        </span>
        <span style={{ color: "#c8d0da", fontSize: "0.72rem", fontWeight: 600, letterSpacing: "0.12em" }}>
          ANI-TRACK
        </span>
        <span style={{ color: "#3d4e62", fontSize: "0.65rem", letterSpacing: "0.08em" }}>
          追跡
        </span>
      </div>

      {/* Tabs */}
      <div className="flex items-stretch">
        {tabs.map((tab) => {
          const active = view === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onViewChange(tab.id)}
              className="flex items-center px-5 gap-1.5 border-r relative"
              style={{
                borderColor: "rgba(255,255,255,0.07)",
                background: active ? "#111520" : "transparent",
                color: active ? "#c8d0da" : "#3d4e62",
                fontSize: "0.68rem",
                letterSpacing: "0.1em",
                cursor: "pointer",
                fontFamily: MONO,
              }}
            >
              {active && (
                <span
                  className="absolute bottom-0 left-0 right-0 h-px"
                  style={{ background: "#b83040" }}
                />
              )}
              <span style={{ color: active ? "#b83040" : "#2a3545", fontSize: "0.6rem" }}>
                [{tab.key}]
              </span>
              {tab.label}
              {tab.id === "library" && (
                <span style={{ color: "#3d4e62", fontSize: "0.6rem" }}>{totalInLib}</span>
              )}
            </button>
          );
        })}
      </div>

      <div className="flex-1" />

      {/* Search */}
      <div
        className="flex items-center px-3 border-l gap-2"
        style={{
          borderColor: searchFocused ? "#b83040" : "rgba(255,255,255,0.07)",
          minWidth: 220,
          transition: "border-color 0.15s",
        }}
      >
        <span style={{ color: "#3d4e62", fontSize: "0.65rem" }}>/</span>
        <input
          value={searchQuery}
          onChange={(e) => onSearch(e.target.value)}
          onFocus={() => setSearchFocused(true)}
          onBlur={() => setSearchFocused(false)}
          placeholder="search library..."
          className="flex-1 bg-transparent outline-none text-xs"
          style={{
            fontFamily: MONO,
            color: "#8a96a4",
            fontSize: "0.68rem",
            caretColor: "#b83040",
          }}
        />
        {searchQuery && (
          <button
            onClick={() => onSearch("")}
            style={{ color: "#3d4e62", fontSize: "0.65rem", cursor: "pointer" }}
          >
            ×
          </button>
        )}
      </div>

      {/* Clock / version badge */}
      <div
        className="flex items-center px-3 border-l gap-3 flex-shrink-0"
        style={{ borderColor: "rgba(255,255,255,0.07)" }}
      >
        <span style={{ color: "#2a3545", fontSize: "0.6rem", letterSpacing: "0.05em" }}>
          v0.1.0
        </span>
      </div>
    </div>
  );
}
