interface GenreFilterProps {
  genres: string[];
  selected: string;
  onSelect: (genre: string) => void;
}

export function GenreFilter({ genres, selected, onSelect }: GenreFilterProps) {
  return (
    <div className="flex items-center gap-3 px-8 md:px-16 mb-10 overflow-x-auto pb-2" style={{ scrollbarWidth: "none" }}>
      <span className="text-xs uppercase tracking-widest flex-shrink-0" style={{ fontFamily: "'Cinzel', serif", color: "#7a8499", letterSpacing: "0.15em" }}>
        Genre
      </span>
      <div className="w-px h-4" style={{ background: "rgba(255,255,255,0.1)" }} />
      {genres.map((g) => (
        <button
          key={g}
          onClick={() => onSelect(g)}
          className="flex-shrink-0 px-4 py-1.5 rounded-full text-xs transition-all duration-200"
          style={{
            fontFamily: "'DM Sans', sans-serif",
            fontWeight: 500,
            letterSpacing: "0.04em",
            background: selected === g ? "#c0182b" : "rgba(255,255,255,0.06)",
            color: selected === g ? "#fff" : "#7a8499",
            border: selected === g ? "1px solid #c0182b" : "1px solid rgba(255,255,255,0.1)",
            transform: selected === g ? "scale(1.05)" : "scale(1)",
          }}
        >
          {g}
        </button>
      ))}
    </div>
  );
}
