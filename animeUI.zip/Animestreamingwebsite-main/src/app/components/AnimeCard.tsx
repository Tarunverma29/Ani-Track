import { useState } from "react";
import { Play, Plus, Star, ChevronRight } from "lucide-react";
import { Anime } from "./animeData";

interface AnimeCardProps {
  anime: Anime;
  onPlay: (anime: Anime) => void;
  showProgress?: boolean;
  size?: "sm" | "md" | "lg";
}

export function AnimeCard({ anime, onPlay, showProgress = false, size = "md" }: AnimeCardProps) {
  const [hovered, setHovered] = useState(false);

  const widths = { sm: 140, md: 180, lg: 220 };
  const w = widths[size];

  return (
    <div
      className="relative flex-shrink-0 cursor-pointer rounded overflow-hidden group"
      style={{
        width: w,
        transition: "transform 0.25s ease, box-shadow 0.25s ease",
        transform: hovered ? "scale(1.06)" : "scale(1)",
        boxShadow: hovered ? "0 12px 40px rgba(0,0,0,0.7)" : "none",
        zIndex: hovered ? 10 : 1,
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      onClick={() => onPlay(anime)}
    >
      {/* Poster */}
      <div className="relative" style={{ height: w * 1.45, background: "#0d1120" }}>
        <img
          src={anime.image}
          alt={anime.title}
          className="w-full h-full object-cover"
          style={{ transition: "filter 0.3s", filter: hovered ? "brightness(0.5) saturate(0.7)" : "brightness(0.85) saturate(0.9)" }}
        />

        {/* Badges */}
        <div className="absolute top-2 left-2 flex gap-1.5">
          {anime.isNew && (
            <span
              className="px-1.5 py-0.5 rounded text-xs font-semibold"
              style={{ background: "#c0182b", color: "#fff", fontFamily: "'DM Sans', sans-serif", fontSize: "0.65rem" }}
            >
              NEW
            </span>
          )}
          {anime.isTrending && (
            <span
              className="px-1.5 py-0.5 rounded text-xs"
              style={{ background: "#c8991a", color: "#07090f", fontFamily: "'DM Sans', sans-serif", fontSize: "0.65rem", fontWeight: 700 }}
            >
              HOT
            </span>
          )}
        </div>

        {/* Rating badge */}
        <div
          className="absolute top-2 right-2 flex items-center gap-0.5 px-1.5 py-0.5 rounded"
          style={{ background: "rgba(7,9,15,0.8)", backdropFilter: "blur(4px)" }}
        >
          <Star size={9} fill="#c8991a" style={{ color: "#c8991a" }} />
          <span className="text-white" style={{ fontSize: "0.65rem", fontFamily: "'DM Sans', sans-serif" }}>
            {anime.rating}
          </span>
        </div>

        {/* Hover overlay */}
        {hovered && (
          <div className="absolute inset-0 flex flex-col justify-end p-3">
            <button
              className="w-full flex items-center justify-center gap-2 py-2 rounded mb-2 transition hover:opacity-90"
              style={{ background: "#c0182b", color: "#fff", fontFamily: "'DM Sans', sans-serif", fontSize: "0.8rem", fontWeight: 600 }}
              onClick={(e) => { e.stopPropagation(); onPlay(anime); }}
            >
              <Play size={13} fill="white" />
              Play
            </button>
            <button
              className="w-full flex items-center justify-center gap-2 py-2 rounded transition hover:opacity-90"
              style={{ background: "rgba(255,255,255,0.15)", color: "#fff", fontFamily: "'DM Sans', sans-serif", fontSize: "0.8rem", border: "1px solid rgba(255,255,255,0.2)" }}
              onClick={(e) => e.stopPropagation()}
            >
              <Plus size={13} />
              Add
            </button>
            <div className="mt-2 flex gap-1 flex-wrap">
              {anime.genre.slice(0, 2).map((g) => (
                <span key={g} className="text-xs" style={{ color: "#7a8499", fontFamily: "'DM Sans', sans-serif", fontSize: "0.65rem" }}>
                  {g}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Progress bar */}
        {showProgress && anime.progress !== undefined && (
          <div className="absolute bottom-0 left-0 right-0 h-1" style={{ background: "rgba(255,255,255,0.15)" }}>
            <div
              className="h-full"
              style={{ width: `${anime.progress}%`, background: "#c0182b" }}
            />
          </div>
        )}
      </div>

      {/* Title below */}
      <div
        className="px-2 pt-2 pb-1"
        style={{ background: "#0d1120" }}
      >
        <p
          className="text-white truncate"
          style={{ fontFamily: "'DM Sans', sans-serif", fontWeight: 500, fontSize: "0.8rem" }}
        >
          {anime.title}
        </p>
        <p style={{ fontFamily: "'Noto Sans JP', sans-serif", fontSize: "0.65rem", color: "#7a8499" }}>
          {anime.titleJp}
        </p>
      </div>
    </div>
  );
}
