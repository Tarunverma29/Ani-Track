import { TrackedAnime, WatchStatus, ALL_STATUSES, STATUS_COLORS } from "./trackingData";

interface TuiDetailProps {
  anime: TrackedAnime;
  onClose: () => void;
  onStatusChange: (id: number, status: WatchStatus) => void;
  onScoreChange: (id: number, score: number | null) => void;
  onEpChange: (id: number, delta: number) => void;
}

const MONO = "'JetBrains Mono', monospace";

function Field({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <div className="flex items-baseline gap-3 py-1 border-b" style={{ borderColor: "rgba(255,255,255,0.04)" }}>
      <span style={{ color: "#3d4e62", fontSize: "0.6rem", letterSpacing: "0.08em", minWidth: 72, flexShrink: 0 }}>
        {label}
      </span>
      <span style={{ color: accent ? "#c8991a" : "#8a96a4", fontSize: "0.68rem", fontFamily: MONO }}>
        {value}
      </span>
    </div>
  );
}

export function TuiDetail({ anime, onClose, onStatusChange, onScoreChange, onEpChange }: TuiDetailProps) {
  const pct = anime.totalEpisodes > 0
    ? Math.round((anime.episodesWatched / anime.totalEpisodes) * 100)
    : 0;

  return (
    <div
      className="flex-shrink-0 flex flex-col border-l overflow-hidden"
      style={{ width: 280, borderColor: "rgba(255,255,255,0.07)", background: "#090b0e", fontFamily: MONO }}
    >
      {/* Panel header */}
      <div
        className="flex items-center justify-between px-3 border-b flex-shrink-0"
        style={{ height: 26, borderColor: "rgba(255,255,255,0.07)", background: "#0c0f14" }}
      >
        <span style={{ color: "#3d4e62", fontSize: "0.6rem", letterSpacing: "0.1em" }}>DETAIL</span>
        <button
          onClick={onClose}
          style={{ color: "#3d4e62", fontSize: "0.65rem", cursor: "pointer", letterSpacing: "0.05em" }}
        >
          [esc]
        </button>
      </div>

      {/* Thumbnail */}
      <div
        className="flex-shrink-0 relative overflow-hidden"
        style={{ height: 130, background: "#0c0f14" }}
      >
        <img
          src={anime.banner}
          alt={anime.title}
          className="w-full h-full object-cover"
          style={{ filter: "brightness(0.3) saturate(0.4)" }}
        />
        {/* Overlay text */}
        <div className="absolute inset-0 flex flex-col justify-end px-3 pb-2">
          <div
            style={{
              fontFamily: "'Noto Sans JP', sans-serif",
              fontSize: "0.75rem",
              color: "#b83040",
              letterSpacing: "0.08em",
              marginBottom: 2,
            }}
          >
            {anime.titleJp}
          </div>
          <div
            style={{ color: "#c8d0da", fontSize: "0.78rem", fontWeight: 600, letterSpacing: "0.04em" }}
          >
            {anime.title}
          </div>
        </div>
        {/* Left red rule */}
        <div
          className="absolute left-0 top-0 bottom-0 w-px"
          style={{ background: "#b83040" }}
        />
      </div>

      {/* Scrollable body */}
      <div className="flex-1 overflow-y-auto px-3 py-2">
        {/* Episode progress */}
        <div className="mb-4">
          <div className="flex items-center justify-between mb-1.5">
            <span style={{ color: "#3d4e62", fontSize: "0.58rem", letterSpacing: "0.1em" }}>PROGRESS</span>
            <span className="tabular-nums" style={{ color: "#4a5870", fontSize: "0.6rem" }}>
              {anime.episodesWatched} / {anime.totalEpisodes}  {pct}%
            </span>
          </div>
          <div className="relative h-px w-full" style={{ background: "#1a2235" }}>
            <div
              className="absolute left-0 top-0 h-full"
              style={{ width: `${pct}%`, background: "#b83040", transition: "width 0.2s" }}
            />
          </div>
          {/* Episode controls */}
          {anime.status !== "completed" && anime.status !== "planning" && (
            <div className="flex gap-2 mt-2">
              <button
                onClick={() => onEpChange(anime.id, -1)}
                className="flex-1 py-1 text-center border transition hover:opacity-80"
                style={{ borderColor: "rgba(255,255,255,0.08)", color: "#b83040", fontSize: "0.65rem", cursor: "pointer" }}
              >
                − ep
              </button>
              <button
                onClick={() => onEpChange(anime.id, 1)}
                className="flex-1 py-1 text-center border transition hover:opacity-80"
                style={{ borderColor: "rgba(255,255,255,0.08)", color: "#3a7a8c", fontSize: "0.65rem", cursor: "pointer" }}
              >
                + ep
              </button>
            </div>
          )}
        </div>

        {/* Status selector */}
        <div className="mb-4">
          <div style={{ color: "#3d4e62", fontSize: "0.58rem", letterSpacing: "0.1em", marginBottom: 6 }}>STATUS</div>
          <div className="flex flex-wrap gap-1">
            {ALL_STATUSES.map((s) => {
              const active = anime.status === s;
              return (
                <button
                  key={s}
                  onClick={() => onStatusChange(anime.id, s)}
                  className="px-2 py-0.5 text-xs transition"
                  style={{
                    fontFamily: MONO,
                    fontSize: "0.58rem",
                    letterSpacing: "0.06em",
                    background: active ? STATUS_COLORS[s] : "transparent",
                    color: active ? "#0a0c10" : STATUS_COLORS[s],
                    border: `1px solid ${STATUS_COLORS[s]}`,
                    cursor: "pointer",
                    fontWeight: active ? 700 : 400,
                    opacity: active ? 1 : 0.6,
                  }}
                >
                  {s.toUpperCase()}
                </button>
              );
            })}
          </div>
        </div>

        {/* Score */}
        <div className="mb-4">
          <div style={{ color: "#3d4e62", fontSize: "0.58rem", letterSpacing: "0.1em", marginBottom: 6 }}>YOUR SCORE</div>
          <div className="flex gap-1">
            {[1,2,3,4,5,6,7,8,9,10].map((n) => (
              <button
                key={n}
                onClick={() => onScoreChange(anime.id, anime.userScore === n ? null : n)}
                className="w-6 h-6 flex items-center justify-center border transition"
                style={{
                  fontFamily: MONO,
                  fontSize: "0.58rem",
                  background: anime.userScore !== null && n <= anime.userScore ? "rgba(200,153,26,0.15)" : "transparent",
                  color: anime.userScore !== null && n <= anime.userScore ? "#c8991a" : "#2a3545",
                  borderColor: anime.userScore !== null && n <= anime.userScore ? "rgba(200,153,26,0.4)" : "rgba(255,255,255,0.06)",
                  cursor: "pointer",
                }}
              >
                {n}
              </button>
            ))}
          </div>
        </div>

        {/* Metadata */}
        <div className="mb-4">
          <Field label="STUDIO" value={anime.studio} />
          <Field label="YEAR" value={String(anime.year)} />
          <Field label="SEASON" value={anime.season} />
          <Field label="RATING" value={`${anime.rating}/10`} accent />
          <Field label="TYPE" value={anime.type} />
          <Field label="DURATION" value={anime.duration} />
          <Field label="ADDED" value={anime.addedDate} />
          <Field label="UPDATED" value={anime.lastUpdated} />
        </div>

        {/* Genres */}
        <div className="mb-4">
          <div style={{ color: "#3d4e62", fontSize: "0.58rem", letterSpacing: "0.1em", marginBottom: 6 }}>GENRES</div>
          <div className="flex flex-wrap gap-1">
            {anime.genre.map((g) => (
              <span
                key={g}
                className="px-2 py-0.5"
                style={{
                  fontFamily: MONO,
                  fontSize: "0.58rem",
                  color: "#3d4e62",
                  border: "1px solid rgba(255,255,255,0.07)",
                  letterSpacing: "0.06em",
                }}
              >
                {g}
              </span>
            ))}
          </div>
        </div>

        {/* Synopsis */}
        <div>
          <div style={{ color: "#3d4e62", fontSize: "0.58rem", letterSpacing: "0.1em", marginBottom: 6 }}>SYNOPSIS</div>
          <p
            style={{
              color: "#4a5870",
              fontSize: "0.65rem",
              lineHeight: 1.7,
              fontFamily: MONO,
            }}
          >
            {anime.synopsis}
          </p>
        </div>
      </div>
    </div>
  );
}
