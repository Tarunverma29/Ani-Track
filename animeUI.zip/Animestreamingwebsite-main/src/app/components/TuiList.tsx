import { TrackedAnime, STATUS_COLORS, WatchStatus } from "./trackingData";

interface TuiListProps {
  items: TrackedAnime[];
  selectedId: number | null;
  onSelect: (id: number) => void;
  onUpdateEp: (id: number, delta: number) => void;
}

const MONO = "'JetBrains Mono', monospace";

const COL_WIDTHS = {
  cursor:  20,
  num:     32,
  title:   "1fr",
  ep:      100,
  score:   64,
  status:  88,
  type:    52,
  updated: 88,
};

function EpBar({ watched, total }: { watched: number; total: number }) {
  const pct = total > 0 ? Math.round((watched / total) * 100) : 0;
  return (
    <div className="flex items-center gap-2 w-full">
      <div className="flex-1 h-px relative" style={{ background: "#1a2235" }}>
        {pct > 0 && (
          <div
            className="absolute left-0 top-0 h-full"
            style={{ width: `${pct}%`, background: "#b83040", transition: "width 0.2s" }}
          />
        )}
      </div>
      <span className="tabular-nums flex-shrink-0" style={{ color: "#4a5870", fontSize: "0.6rem", minWidth: 56, textAlign: "right" }}>
        {watched}/{total}
      </span>
    </div>
  );
}

export function TuiList({ items, selectedId, onSelect, onUpdateEp }: TuiListProps) {
  if (items.length === 0) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center gap-3" style={{ fontFamily: MONO }}>
        <div style={{ color: "#1e2a38", fontSize: "2.5rem", fontFamily: "'Noto Sans JP', sans-serif" }}>
          見つかりません
        </div>
        <div style={{ color: "#3d4e62", fontSize: "0.7rem", letterSpacing: "0.1em" }}>
          NO ENTRIES FOUND
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-hidden flex flex-col" style={{ fontFamily: MONO }}>
      {/* Column headers */}
      <div
        className="flex-shrink-0 flex items-center border-b px-3"
        style={{
          height: 26,
          borderColor: "rgba(255,255,255,0.07)",
          background: "#0a0c10",
        }}
      >
        <div style={{ width: COL_WIDTHS.cursor }} />
        <div style={{ width: COL_WIDTHS.num, color: "#2a3545", fontSize: "0.58rem", letterSpacing: "0.08em" }}>#</div>
        <div style={{ flex: 1, color: "#3d4e62", fontSize: "0.6rem", letterSpacing: "0.08em" }}>TITLE</div>
        <div style={{ width: COL_WIDTHS.ep, color: "#3d4e62", fontSize: "0.6rem", letterSpacing: "0.08em" }}>PROGRESS</div>
        <div style={{ width: COL_WIDTHS.score, color: "#3d4e62", fontSize: "0.6rem", letterSpacing: "0.08em", textAlign: "right" }}>SCORE</div>
        <div style={{ width: COL_WIDTHS.status, color: "#3d4e62", fontSize: "0.6rem", letterSpacing: "0.08em", paddingLeft: 12 }}>STATUS</div>
        <div style={{ width: COL_WIDTHS.type, color: "#3d4e62", fontSize: "0.6rem", letterSpacing: "0.08em" }}>TYPE</div>
        <div style={{ width: COL_WIDTHS.updated, color: "#3d4e62", fontSize: "0.6rem", letterSpacing: "0.08em", textAlign: "right" }}>UPDATED</div>
      </div>

      {/* Rows */}
      <div className="flex-1 overflow-y-auto">
        {items.map((anime, idx) => {
          const selected = selectedId === anime.id;
          const statusColor = STATUS_COLORS[anime.status];
          return (
            <div
              key={anime.id}
              onClick={() => onSelect(anime.id)}
              className="flex items-center px-3 border-b relative cursor-pointer group"
              style={{
                height: 36,
                borderColor: "rgba(255,255,255,0.04)",
                background: selected ? "#111520" : "transparent",
                transition: "background 0.1s",
              }}
            >
              {/* Selected indicator */}
              {selected && (
                <span
                  className="absolute left-0 top-0 bottom-0 w-px"
                  style={{ background: "#b83040" }}
                />
              )}

              {/* Cursor col */}
              <div style={{ width: COL_WIDTHS.cursor, color: selected ? "#b83040" : "transparent", fontSize: "0.65rem" }}>
                ▶
              </div>

              {/* Row number */}
              <div
                className="tabular-nums"
                style={{ width: COL_WIDTHS.num, color: "#2a3545", fontSize: "0.6rem" }}
              >
                {String(idx + 1).padStart(2, "0")}
              </div>

              {/* Title */}
              <div style={{ flex: 1, overflow: "hidden", paddingRight: 12 }}>
                <div className="flex items-baseline gap-2 overflow-hidden">
                  <span
                    className="truncate"
                    style={{ color: selected ? "#e0e8f0" : "#8a96a4", fontSize: "0.72rem", fontWeight: selected ? 500 : 400 }}
                  >
                    {anime.title}
                  </span>
                  <span
                    className="truncate flex-shrink-0"
                    style={{ fontFamily: "'Noto Sans JP', sans-serif", color: "#2a3545", fontSize: "0.65rem" }}
                  >
                    {anime.titleJp}
                  </span>
                </div>
              </div>

              {/* Progress */}
              <div style={{ width: COL_WIDTHS.ep, paddingRight: 8 }}>
                {anime.status === "planning" ? (
                  <span style={{ color: "#2a3545", fontSize: "0.6rem" }}>–</span>
                ) : (
                  <EpBar watched={anime.episodesWatched} total={anime.totalEpisodes} />
                )}
              </div>

              {/* Score */}
              <div
                className="tabular-nums"
                style={{ width: COL_WIDTHS.score, textAlign: "right", paddingRight: 12 }}
              >
                {anime.userScore !== null ? (
                  <span style={{ color: "#c8991a", fontSize: "0.7rem", fontWeight: 600 }}>
                    {anime.userScore}
                    <span style={{ color: "#3d4e62", fontWeight: 400 }}>/10</span>
                  </span>
                ) : (
                  <span style={{ color: "#2a3545", fontSize: "0.68rem" }}>–</span>
                )}
              </div>

              {/* Status */}
              <div style={{ width: COL_WIDTHS.status, paddingLeft: 12 }}>
                <span
                  style={{
                    color: statusColor,
                    fontSize: "0.6rem",
                    letterSpacing: "0.06em",
                    fontWeight: 500,
                  }}
                >
                  {anime.status.toUpperCase()}
                </span>
              </div>

              {/* Type */}
              <div style={{ width: COL_WIDTHS.type }}>
                <span style={{ color: "#3d4e62", fontSize: "0.6rem" }}>{anime.type}</span>
              </div>

              {/* Updated */}
              <div
                className="tabular-nums"
                style={{ width: COL_WIDTHS.updated, textAlign: "right", color: "#3d4e62", fontSize: "0.6rem" }}
              >
                {anime.lastUpdated}
              </div>

              {/* Hover ep controls — overlay */}
              {anime.status !== "planning" && anime.status !== "completed" && (
                <div
                  className="absolute right-3 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity"
                  style={{ pointerEvents: "none" }}
                >
                  <button
                    style={{
                      pointerEvents: "all",
                      background: "#111520",
                      border: "1px solid rgba(255,255,255,0.08)",
                      color: "#b83040",
                      fontSize: "0.65rem",
                      width: 18,
                      height: 18,
                      cursor: "pointer",
                      fontFamily: MONO,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                    onClick={(e) => { e.stopPropagation(); onUpdateEp(anime.id, -1); }}
                  >
                    −
                  </button>
                  <button
                    style={{
                      pointerEvents: "all",
                      background: "#111520",
                      border: "1px solid rgba(255,255,255,0.08)",
                      color: "#3a7a8c",
                      fontSize: "0.65rem",
                      width: 18,
                      height: 18,
                      cursor: "pointer",
                      fontFamily: MONO,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                    onClick={(e) => { e.stopPropagation(); onUpdateEp(anime.id, 1); }}
                  >
                    +
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
