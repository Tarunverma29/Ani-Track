import { WatchStatus } from "./trackingData";

interface TuiStatusBarProps {
  view: string;
  activeStatus: WatchStatus | "all";
  filteredCount: number;
  selectedTitle?: string;
  message?: string;
}

const MONO = "'JetBrains Mono', monospace";

function Key({ k, label }: { k: string; label: string }) {
  return (
    <span className="flex items-center gap-1" style={{ color: "#3d4e62", fontSize: "0.58rem" }}>
      <span style={{ color: "#4a5870", background: "#111520", border: "1px solid rgba(255,255,255,0.08)", padding: "0 4px", letterSpacing: "0.04em" }}>
        {k}
      </span>
      <span style={{ color: "#2a3545" }}>{label}</span>
    </span>
  );
}

export function TuiStatusBar({ view, activeStatus, filteredCount, selectedTitle, message }: TuiStatusBarProps) {
  const libraryKeys = [
    { k: "j/k", label: "navigate" },
    { k: "enter", label: "detail" },
    { k: "e", label: "edit ep" },
    { k: "/", label: "search" },
    { k: "esc", label: "close" },
  ];
  const discoverKeys = [
    { k: "/", label: "focus search" },
    { k: "enter", label: "add" },
    { k: "esc", label: "cancel" },
  ];
  const statsKeys = [{ k: "r", label: "refresh" }];

  const keys = view === "library" ? libraryKeys : view === "discover" ? discoverKeys : statsKeys;

  return (
    <div
      className="flex-shrink-0 flex items-center justify-between border-t px-3"
      style={{
        height: 24,
        borderColor: "rgba(255,255,255,0.07)",
        background: "#0a0c10",
        fontFamily: MONO,
      }}
    >
      {/* Left: keybinds */}
      <div className="flex items-center gap-4">
        {keys.map(({ k, label }) => (
          <Key key={k} k={k} label={label} />
        ))}
      </div>

      {/* Center: message or selected */}
      <div className="flex items-center gap-2">
        {message ? (
          <span style={{ color: "#3a7a8c", fontSize: "0.6rem", letterSpacing: "0.06em" }}>{message}</span>
        ) : selectedTitle ? (
          <span style={{ color: "#4a5870", fontSize: "0.6rem" }}>
            selected: <span style={{ color: "#8a96a4" }}>{selectedTitle}</span>
          </span>
        ) : null}
      </div>

      {/* Right: status context */}
      <div className="flex items-center gap-4">
        {view === "library" && (
          <span className="tabular-nums" style={{ color: "#2a3545", fontSize: "0.6rem" }}>
            {filteredCount} entries
          </span>
        )}
        <span style={{ color: "#2a3545", fontSize: "0.6rem", letterSpacing: "0.1em" }}>
          {view.toUpperCase()}
        </span>
        <span style={{ fontFamily: "'Noto Sans JP', sans-serif", color: "#1e2a38", fontSize: "0.65rem" }}>
          {view === "library" ? "ライブラリ" : view === "discover" ? "発見" : "統計"}
        </span>
      </div>
    </div>
  );
}
