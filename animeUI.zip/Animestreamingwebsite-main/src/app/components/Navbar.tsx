import { useState } from "react";
import { Search, Bell, User, Menu, X, Play } from "lucide-react";

interface NavbarProps {
  onSearch: (q: string) => void;
}

export function Navbar({ onSearch }: NavbarProps) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState("");

  const navLinks = ["Home", "Trending", "New", "My List", "Browse"];

  return (
    <nav
      className="fixed top-0 left-0 right-0 z-50 transition-all duration-300"
      style={{
        background: "linear-gradient(to bottom, rgba(7,9,15,0.97) 0%, rgba(7,9,15,0.8) 70%, transparent 100%)",
        backdropFilter: "blur(2px)",
      }}
    >
      <div className="max-w-screen-2xl mx-auto px-6 py-4 flex items-center gap-8">
        {/* Logo */}
        <a href="#" className="flex items-center gap-2 flex-shrink-0">
          <div className="w-8 h-8 rounded flex items-center justify-center" style={{ background: "#c0182b" }}>
            <Play size={16} fill="white" className="text-white ml-0.5" />
          </div>
          <span
            className="text-white tracking-widest uppercase"
            style={{ fontFamily: "'Cinzel', serif", fontWeight: 700, fontSize: "1.1rem", letterSpacing: "0.15em" }}
          >
            AniStream
          </span>
          <span
            className="hidden sm:inline text-xs tracking-widest"
            style={{ fontFamily: "'Noto Sans JP', sans-serif", color: "#c8991a", letterSpacing: "0.1em" }}
          >
            アニメ
          </span>
        </a>

        {/* Desktop nav links */}
        <div className="hidden md:flex items-center gap-6">
          {navLinks.map((link) => (
            <a
              key={link}
              href="#"
              className="text-sm transition-colors duration-200 hover:text-white"
              style={{
                fontFamily: "'DM Sans', sans-serif",
                color: link === "Home" ? "#ffffff" : "#7a8499",
                letterSpacing: "0.05em",
              }}
            >
              {link}
            </a>
          ))}
        </div>

        <div className="flex-1" />

        {/* Search */}
        <div className="hidden md:flex items-center">
          {searchOpen ? (
            <div className="flex items-center gap-2 border-b" style={{ borderColor: "#c0182b" }}>
              <Search size={16} style={{ color: "#7a8499" }} />
              <input
                autoFocus
                className="bg-transparent text-sm text-white outline-none w-48 pb-1"
                placeholder="Search anime..."
                style={{ fontFamily: "'DM Sans', sans-serif" }}
                value={query}
                onChange={(e) => { setQuery(e.target.value); onSearch(e.target.value); }}
                onBlur={() => { if (!query) setSearchOpen(false); }}
              />
              <button onClick={() => { setSearchOpen(false); setQuery(""); onSearch(""); }}>
                <X size={14} style={{ color: "#7a8499" }} />
              </button>
            </div>
          ) : (
            <button onClick={() => setSearchOpen(true)} className="p-2 transition-colors hover:text-white" style={{ color: "#7a8499" }}>
              <Search size={18} />
            </button>
          )}
        </div>

        {/* Notifications */}
        <button className="hidden md:flex p-2 transition-colors hover:text-white relative" style={{ color: "#7a8499" }}>
          <Bell size={18} />
          <span
            className="absolute top-1 right-1 w-2 h-2 rounded-full"
            style={{ background: "#c0182b" }}
          />
        </button>

        {/* Avatar */}
        <button className="hidden md:flex items-center gap-2">
          <div
            className="w-8 h-8 rounded-full flex items-center justify-center text-xs text-white"
            style={{ background: "linear-gradient(135deg, #c0182b, #7c1020)", fontFamily: "'Cinzel', serif" }}
          >
            K
          </div>
        </button>

        {/* Mobile menu toggle */}
        <button
          className="md:hidden p-2 text-white"
          onClick={() => setMenuOpen(!menuOpen)}
        >
          {menuOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div
          className="md:hidden px-6 pb-6 flex flex-col gap-4 border-t"
          style={{ borderColor: "rgba(255,255,255,0.07)", background: "rgba(7,9,15,0.97)" }}
        >
          <div className="flex items-center gap-2 mt-4 border-b pb-3" style={{ borderColor: "#c0182b" }}>
            <Search size={16} style={{ color: "#7a8499" }} />
            <input
              className="bg-transparent text-sm text-white outline-none flex-1"
              placeholder="Search anime..."
              style={{ fontFamily: "'DM Sans', sans-serif" }}
              value={query}
              onChange={(e) => { setQuery(e.target.value); onSearch(e.target.value); }}
            />
          </div>
          {navLinks.map((link) => (
            <a
              key={link}
              href="#"
              className="text-sm py-1"
              style={{ fontFamily: "'DM Sans', sans-serif", color: "#c8cdd8" }}
              onClick={() => setMenuOpen(false)}
            >
              {link}
            </a>
          ))}
        </div>
      )}
    </nav>
  );
}
