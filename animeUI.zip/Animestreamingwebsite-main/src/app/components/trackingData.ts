export type WatchStatus = "watching" | "completed" | "planning" | "on-hold" | "dropped";

export interface TrackedAnime {
  id: number;
  title: string;
  titleJp: string;
  genre: string[];
  totalEpisodes: number;
  episodesWatched: number;
  status: WatchStatus;
  userScore: number | null;
  rating: number;        // community rating
  year: number;
  studio: string;
  synopsis: string;
  image: string;
  banner: string;
  lastUpdated: string;   // relative string
  addedDate: string;
  season: string;
  type: "TV" | "Movie" | "OVA" | "ONA";
  duration: string;      // per-episode
}

export const library: TrackedAnime[] = [
  {
    id: 1, title: "Demon Slayer", titleJp: "鬼滅の刃",
    genre: ["Action", "Fantasy", "Dark"], totalEpisodes: 44, episodesWatched: 26,
    status: "watching", userScore: 9, rating: 9.2, year: 2019, studio: "ufotable",
    synopsis: "A young boy becomes a demon slayer after his family is slaughtered and his sister is turned into a demon. A breathtaking journey through a world of darkness and beauty.",
    image: "https://images.unsplash.com/photo-1597839219216-a773cb2473e4?w=400&h=560&fit=crop&auto=format",
    banner: "https://images.unsplash.com/photo-1601042879364-f3947d3f9c16?w=800&h=300&fit=crop&auto=format",
    lastUpdated: "2h ago", addedDate: "2024-01-12", season: "Spring 2019", type: "TV", duration: "24 min",
  },
  {
    id: 2, title: "Jujutsu Kaisen", titleJp: "呪術廻戦",
    genre: ["Action", "Supernatural", "Horror"], totalEpisodes: 47, episodesWatched: 12,
    status: "watching", userScore: 8, rating: 8.9, year: 2020, studio: "MAPPA",
    synopsis: "A boy swallows a cursed talisman and becomes host to a powerful demon. He joins a secret organization of sorcerers to find and destroy the demon's scattered remains.",
    image: "https://images.unsplash.com/photo-1573455494060-c5595004fb6c?w=400&h=560&fit=crop&auto=format",
    banner: "https://images.unsplash.com/photo-1573455494060-c5595004fb6c?w=800&h=300&fit=crop&auto=format",
    lastUpdated: "1d ago", addedDate: "2024-02-03", season: "Fall 2020", type: "TV", duration: "24 min",
  },
  {
    id: 3, title: "Cowboy Bebop", titleJp: "カウボーイビバップ",
    genre: ["Sci-Fi", "Action", "Jazz"], totalEpisodes: 26, episodesWatched: 11,
    status: "watching", userScore: null, rating: 9.0, year: 1998, studio: "Sunrise",
    synopsis: "A ragtag group of bounty hunters chase criminals across the solar system while haunted by their troubled pasts. Jazz, blues, and existential dread in space.",
    image: "https://images.unsplash.com/photo-1475070929565-c985b496cb9f?w=400&h=560&fit=crop&auto=format",
    banner: "https://images.unsplash.com/photo-1475070929565-c985b496cb9f?w=800&h=300&fit=crop&auto=format",
    lastUpdated: "3d ago", addedDate: "2023-11-20", season: "Spring 1998", type: "TV", duration: "25 min",
  },
  {
    id: 4, title: "One Punch Man", titleJp: "ワンパンマン",
    genre: ["Action", "Comedy", "Superhero"], totalEpisodes: 24, episodesWatched: 5,
    status: "watching", userScore: null, rating: 8.8, year: 2015, studio: "Madhouse",
    synopsis: "A hero who can defeat any enemy with a single punch grows bored of his overwhelming power and searches for someone who can give him a real challenge.",
    image: "https://images.unsplash.com/photo-1616265350912-9ed401ac47ac?w=400&h=560&fit=crop&auto=format",
    banner: "https://images.unsplash.com/photo-1616265350912-9ed401ac47ac?w=800&h=300&fit=crop&auto=format",
    lastUpdated: "5d ago", addedDate: "2024-03-01", season: "Fall 2015", type: "TV", duration: "24 min",
  },
  {
    id: 5, title: "Attack on Titan", titleJp: "進撃の巨人",
    genre: ["Action", "Drama", "Horror"], totalEpisodes: 87, episodesWatched: 87,
    status: "completed", userScore: 10, rating: 9.4, year: 2013, studio: "MAPPA",
    synopsis: "Humanity's last survivors cower behind colossal walls as titans devour them at will. One boy's rage against these monsters will reshape the world.",
    image: "https://images.unsplash.com/photo-1491466424936-e304919aada7?w=400&h=560&fit=crop&auto=format",
    banner: "https://images.unsplash.com/photo-1491466424936-e304919aada7?w=800&h=300&fit=crop&auto=format",
    lastUpdated: "2w ago", addedDate: "2023-06-10", season: "Spring 2013", type: "TV", duration: "24 min",
  },
  {
    id: 6, title: "Your Name", titleJp: "君の名は。",
    genre: ["Romance", "Fantasy", "Drama"], totalEpisodes: 1, episodesWatched: 1,
    status: "completed", userScore: 9, rating: 9.1, year: 2016, studio: "CoMix Wave Films",
    synopsis: "Two teenagers share a profound, magical connection upon discovering they are swapping bodies. When the connection suddenly breaks, they set out to find each other.",
    image: "https://images.unsplash.com/photo-1680011810663-7c825cafbbda?w=400&h=560&fit=crop&auto=format",
    banner: "https://images.unsplash.com/photo-1680011810663-7c825cafbbda?w=800&h=300&fit=crop&auto=format",
    lastUpdated: "1mo ago", addedDate: "2023-09-15", season: "–", type: "Movie", duration: "107 min",
  },
  {
    id: 7, title: "Spirited Away", titleJp: "千と千尋の神隠し",
    genre: ["Fantasy", "Adventure", "Family"], totalEpisodes: 1, episodesWatched: 1,
    status: "completed", userScore: 10, rating: 9.3, year: 2001, studio: "Studio Ghibli",
    synopsis: "A young girl wanders into a mysterious spirit world and must work to free herself and her parents who have been turned into pigs.",
    image: "https://images.unsplash.com/photo-1564284369929-026ba231f89b?w=400&h=560&fit=crop&auto=format",
    banner: "https://images.unsplash.com/photo-1564284369929-026ba231f89b?w=800&h=300&fit=crop&auto=format",
    lastUpdated: "3mo ago", addedDate: "2023-07-22", season: "–", type: "Movie", duration: "125 min",
  },
  {
    id: 8, title: "Death Note", titleJp: "デスノート",
    genre: ["Thriller", "Psychological", "Mystery"], totalEpisodes: 37, episodesWatched: 37,
    status: "completed", userScore: 9, rating: 9.0, year: 2006, studio: "Madhouse",
    synopsis: "A genius student discovers a supernatural notebook that kills anyone whose name is written in it. He embarks on a mission to cleanse the world of evil.",
    image: "https://images.unsplash.com/photo-1704050929730-65753014c435?w=400&h=560&fit=crop&auto=format",
    banner: "https://images.unsplash.com/photo-1704050929730-65753014c435?w=800&h=300&fit=crop&auto=format",
    lastUpdated: "4mo ago", addedDate: "2023-04-01", season: "Fall 2006", type: "TV", duration: "23 min",
  },
  {
    id: 9, title: "Fullmetal Alchemist", titleJp: "鋼の錬金術師",
    genre: ["Action", "Drama", "Fantasy"], totalEpisodes: 64, episodesWatched: 0,
    status: "planning", userScore: null, rating: 9.5, year: 2009, studio: "Bones",
    synopsis: "Two brothers search for the philosopher's stone to restore their bodies after a failed alchemical ritual. What they discover will shake the very foundations of the world.",
    image: "https://images.unsplash.com/photo-1586165877141-3dbcfc059283?w=400&h=560&fit=crop&auto=format",
    banner: "https://images.unsplash.com/photo-1586165877141-3dbcfc059283?w=800&h=300&fit=crop&auto=format",
    lastUpdated: "–", addedDate: "2024-03-18", season: "Spring 2009", type: "TV", duration: "24 min",
  },
  {
    id: 10, title: "Princess Mononoke", titleJp: "もののけ姫",
    genre: ["Fantasy", "Adventure", "Drama"], totalEpisodes: 1, episodesWatched: 0,
    status: "planning", userScore: null, rating: 9.1, year: 1997, studio: "Studio Ghibli",
    synopsis: "In war-torn medieval Japan, a young prince becomes involved in a conflict between forest gods and humans consuming their land.",
    image: "https://images.unsplash.com/photo-1610129142564-79956dcecc7b?w=400&h=560&fit=crop&auto=format",
    banner: "https://images.unsplash.com/photo-1610129142564-79956dcecc7b?w=800&h=300&fit=crop&auto=format",
    lastUpdated: "–", addedDate: "2024-03-22", season: "–", type: "Movie", duration: "134 min",
  },
  {
    id: 11, title: "Neon Genesis Evangelion", titleJp: "新世紀エヴァンゲリオン",
    genre: ["Sci-Fi", "Psychological", "Action"], totalEpisodes: 26, episodesWatched: 18,
    status: "on-hold", userScore: null, rating: 9.0, year: 1995, studio: "Gainax",
    synopsis: "In a post-apocalyptic world, teenagers pilot colossal bio-machines called Evangelions to defend humanity against mysterious beings known as Angels.",
    image: "https://images.unsplash.com/photo-1534214526114-0ea4d47b04f2?w=400&h=560&fit=crop&auto=format",
    banner: "https://images.unsplash.com/photo-1534214526114-0ea4d47b04f2?w=800&h=300&fit=crop&auto=format",
    lastUpdated: "3w ago", addedDate: "2023-10-05", season: "Fall 1995", type: "TV", duration: "23 min",
  },
  {
    id: 12, title: "Vinland Saga", titleJp: "ヴィンランド・サガ",
    genre: ["Action", "Historical", "Drama"], totalEpisodes: 48, episodesWatched: 12,
    status: "on-hold", userScore: null, rating: 9.1, year: 2019, studio: "Wit Studio",
    synopsis: "A young Viking boy witnesses his father's murder and vows revenge, setting him on a brutal path across medieval Europe toward a land without war.",
    image: "https://images.unsplash.com/photo-1617541016107-b62971c6e27f?w=400&h=560&fit=crop&auto=format",
    banner: "https://images.unsplash.com/photo-1617541016107-b62971c6e27f?w=800&h=300&fit=crop&auto=format",
    lastUpdated: "2w ago", addedDate: "2023-12-11", season: "Summer 2019", type: "TV", duration: "24 min",
  },
];

export const STATUS_LABELS: Record<WatchStatus, string> = {
  watching: "WATCHING",
  completed: "COMPLETED",
  planning: "PLANNING",
  "on-hold": "ON-HOLD",
  dropped: "DROPPED",
};

export const STATUS_COLORS: Record<WatchStatus, string> = {
  watching: "#3a7a8c",
  completed: "#4c7a50",
  planning: "#5a6a7a",
  "on-hold": "#c8991a",
  dropped: "#6a3040",
};

export const ALL_STATUSES: WatchStatus[] = ["watching", "completed", "planning", "on-hold", "dropped"];

export const GENRES = ["All", "Action", "Fantasy", "Romance", "Sci-Fi", "Horror", "Drama", "Thriller", "Comedy", "Mystery", "Historical", "Psychological"];

// Stats helpers
export function getStats(lib: TrackedAnime[]) {
  const totalEp = lib.reduce((s, a) => s + a.episodesWatched, 0);
  const totalMin = lib.reduce((s, a) => {
    const mins = parseInt(a.duration) || 24;
    return s + a.episodesWatched * mins;
  }, 0);
  const scored = lib.filter(a => a.userScore !== null);
  const avgScore = scored.length ? (scored.reduce((s, a) => s + (a.userScore ?? 0), 0) / scored.length).toFixed(1) : "–";
  return { totalEp, totalMin, avgScore, scored: scored.length };
}
