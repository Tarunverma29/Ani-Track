import { TrackedAnime, getStats, ALL_STATUSES, STATUS_COLORS, WatchStatus } from "./trackingData";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Cell, Tooltip } from "recharts";

const MONO = "'JetBrains Mono', monospace";

interface TuiStatsProps { library: TrackedAnime[] }

function StatBox({ label, value, sub }: { label: string; value: string | number; sub?: string }) {
  return (
    <div className="flex flex-col border p-4 gap-1" style={{ borderColor: "rgba(255,255,255,0.07)" }}>
      <span style={{ color: "#2a3545", fontSize: "0.6rem", letterSpacing: "0.1em" }}>{label}</span>
      <span className="tabular-nums" style={{ color: "#c8d0da", fontSize: "1.4rem", fontWeight: 600, lineHeight: 1 }}>
        {value}
      </span>
      {sub && <span style={{ color: "#3d4e62", fontSize: "0.6rem" }}>{sub}</span>}
    </div>
  );
}

export function TuiStats({ library }: TuiStatsProps) {
  const { totalEp, totalMin, avgScore } = getStats(library);
  const totalHours = (totalMin / 60).toFixed(1);

  // Status breakdown
  const statusData = ALL_STATUSES.map((s) => ({
    status: s.toUpperCase(),
    count: library.filter((a) => a.status === s).length,
    color: STATUS_COLORS[s],
  }));

  // Genre breakdown
  const genreCounts: Record<string, number> = {};
  library.forEach((a) => a.genre.forEach((g) => { genreCounts[g] = (genreCounts[g] || 0) + 1; }));
  const genreData = Object.entries(genreCounts).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([g, c]) => ({ genre: g, count: c }));

  // Score distribution
  const scoreDist = Array.from({ length: 10 }, (_, i) => i + 1).map((s) => ({
    score: String(s),
    count: library.filter((a) => a.userScore === s).length,
  }));

  // Recent activity (sorted by last updated that aren't "–")
  const recent = library
    .filter((a) => a.lastUpdated !== "–")
    .slice(0, 8);

  const CustomTooltip = ({ active, payload }: any) => {
    if (!active || !payload?.length) return null;
    return (
      <div className="border px-2 py-1" style={{ background: "#0c0f14", borderColor: "rgba(255,255,255,0.1)", fontFamily: MONO, fontSize: "0.62rem", color: "#8a96a4" }}>
        {payload[0].value}
      </div>
    );
  };

  return (
    <div className="flex-1 overflow-y-auto p-6" style={{ fontFamily: MONO }}>
      {/* Section title */}
      <div className="flex items-center gap-3 mb-6">
        <span style={{ color: "#2a3545", fontSize: "0.6rem" }}>┌─</span>
        <span style={{ color: "#3d4e62", fontSize: "0.65rem", letterSpacing: "0.12em" }}>STATISTICS 統計</span>
        <div className="flex-1 h-px" style={{ background: "rgba(255,255,255,0.06)" }} />
      </div>

      {/* Top stat boxes */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-8">
        <StatBox label="ENTRIES" value={library.length} sub="in library" />
        <StatBox label="EPISODES" value={totalEp} sub="watched" />
        <StatBox label="HOURS" value={totalHours} sub="time spent" />
        <StatBox label="AVG SCORE" value={avgScore} sub="from rated" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        {/* Status chart */}
        <div className="border p-4" style={{ borderColor: "rgba(255,255,255,0.07)" }}>
          <div style={{ color: "#3d4e62", fontSize: "0.6rem", letterSpacing: "0.1em", marginBottom: 16 }}>
            STATUS BREAKDOWN
          </div>
          <div className="space-y-2">
            {statusData.map(({ status, count, color }) => {
              const pct = library.length > 0 ? (count / library.length) * 100 : 0;
              return (
                <div key={status} className="flex items-center gap-3">
                  <span style={{ color, fontSize: "0.6rem", minWidth: 72, letterSpacing: "0.06em" }}>{status}</span>
                  <div className="flex-1 h-px relative" style={{ background: "#111520" }}>
                    <div className="absolute left-0 top-0 h-full" style={{ width: `${pct}%`, background: color }} />
                  </div>
                  <span className="tabular-nums" style={{ color: "#4a5870", fontSize: "0.6rem", minWidth: 16, textAlign: "right" }}>{count}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Score distribution */}
        <div className="border p-4" style={{ borderColor: "rgba(255,255,255,0.07)" }}>
          <div style={{ color: "#3d4e62", fontSize: "0.6rem", letterSpacing: "0.1em", marginBottom: 12 }}>
            SCORE DISTRIBUTION
          </div>
          <ResponsiveContainer width="100%" height={100}>
            <BarChart data={scoreDist} margin={{ top: 0, right: 0, bottom: 0, left: -20 }} barSize={12}>
              <XAxis dataKey="score" tick={{ fontFamily: MONO, fontSize: 9, fill: "#3d4e62" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontFamily: MONO, fontSize: 9, fill: "#3d4e62" }} axisLine={false} tickLine={false} allowDecimals={false} />
              <Tooltip content={<CustomTooltip />} cursor={{ fill: "rgba(255,255,255,0.03)" }} />
              <Bar dataKey="count" radius={0}>
                {scoreDist.map((_, i) => (
                  <Cell key={i} fill={i >= 7 ? "#c8991a" : i >= 4 ? "#3a7a8c" : "#2a3545"} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Genre breakdown */}
      <div className="border p-4 mb-6" style={{ borderColor: "rgba(255,255,255,0.07)" }}>
        <div style={{ color: "#3d4e62", fontSize: "0.6rem", letterSpacing: "0.1em", marginBottom: 12 }}>
          TOP GENRES
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {genreData.map(({ genre, count }) => (
            <div key={genre} className="flex items-baseline justify-between border-b py-1" style={{ borderColor: "rgba(255,255,255,0.05)" }}>
              <span style={{ color: "#5a6a7a", fontSize: "0.62rem" }}>{genre}</span>
              <span className="tabular-nums" style={{ color: "#8a96a4", fontSize: "0.68rem", fontWeight: 600 }}>{count}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Recent activity */}
      <div className="border p-4" style={{ borderColor: "rgba(255,255,255,0.07)" }}>
        <div style={{ color: "#3d4e62", fontSize: "0.6rem", letterSpacing: "0.1em", marginBottom: 12 }}>
          RECENT ACTIVITY
        </div>
        <div>
          {recent.map((a) => (
            <div
              key={a.id}
              className="flex items-center gap-4 py-1.5 border-b"
              style={{ borderColor: "rgba(255,255,255,0.04)" }}
            >
              <span style={{ color: STATUS_COLORS[a.status], fontSize: "0.58rem", minWidth: 8 }}>■</span>
              <span style={{ color: "#8a96a4", fontSize: "0.68rem", flex: 1 }}>{a.title}</span>
              <span style={{ fontFamily: "'Noto Sans JP', sans-serif", color: "#2a3545", fontSize: "0.65rem" }}>
                {a.titleJp}
              </span>
              <span style={{ color: "#3d4e62", fontSize: "0.6rem", minWidth: 60, textAlign: "right" }}>
                {a.lastUpdated}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
