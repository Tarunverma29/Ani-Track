import { useState, useEffect } from "react";
import { Play, Plus, Info, Star, ChevronLeft, ChevronRight } from "lucide-react";
import { Anime } from "./animeData";

interface HeroSectionProps {
  featured: Anime[];
  onPlay: (anime: Anime) => void;
}

export function HeroSection({ featured, onPlay }: HeroSectionProps) {
  const [current, setCurrent] = useState(0);
  const [fading, setFading] = useState(false);

  const anime = featured[current];

  useEffect(() => {
    const timer = setTimeout(() => {
      goTo((current + 1) % featured.length);
    }, 7000);
    return () => clearTimeout(timer);
  }, [current, featured.length]);

  function goTo(idx: number) {
    setFading(true);
    setTimeout(() => {
      setCurrent(idx);
      setFading(false);
    }, 300);
  }

  return (
    <div className="relative w-full overflow-hidden" style={{ height: "100vh", minHeight: 600 }}>
      {/* Banner image */}
      <div
        className="absolute inset-0 transition-opacity duration-500"
        style={{ opacity: fading ? 0 : 1 }}
      >
        <img
          src={anime.banner || anime.image}
          alt={anime.title}
          className="w-full h-full object-cover"
          style={{ filter: "brightness(0.45) saturate(0.8)" }}
        />
      </div>

      {/* Cinematic vignette overlays */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "linear-gradient(to right, rgba(7,9,15,0.92) 0%, rgba(7,9,15,0.5) 40%, transparent 65%), linear-gradient(to top, rgba(7,9,15,1) 0%, rgba(7,9,15,0.4) 30%, transparent 55%)",
        }}
      />

      {/* Diagonal red accent line */}
      <div
        className="absolute left-0 top-0 h-full w-1"
        style={{ background: "linear-gradient(to bottom, transparent, #c0182b 30%, #c0182b 70%, transparent)" }}
      />

      {/* Content */}
      <div
        className="absolute inset-0 flex flex-col justify-end px-8 md:px-16 pb-32 md:pb-24 max-w-2xl"
        style={{ transition: "opacity 0.5s", opacity: fading ? 0 : 1 }}
      >
        {/* Japanese subtitle tag */}
        <div className="flex items-center gap-3 mb-4">
          <span
            className="text-xs uppercase tracking-widest"
            style={{ fontFamily: "'Cinzel', serif", color: "#c0182b", letterSpacing: "0.2em" }}
          >
            Featured
          </span>
          <span className="w-8 h-px" style={{ background: "#c0182b" }} />
          <span
            className="text-xs"
            style={{ fontFamily: "'Noto Sans JP', sans-serif", color: "#c8991a", letterSpacing: "0.1em" }}
          >
            {anime.titleJp}
          </span>
        </div>

        {/* Title */}
        <h1
          className="text-white mb-3 leading-none"
          style={{
            fontFamily: "'Cinzel', serif",
            fontWeight: 900,
            fontSize: "clamp(2.5rem, 6vw, 5rem)",
            textShadow: "0 2px 40px rgba(0,0,0,0.8)",
            letterSpacing: "-0.01em",
          }}
        >
          {anime.title}
        </h1>

        {/* Meta row */}
        <div className="flex items-center gap-4 mb-5">
          <div className="flex items-center gap-1">
            <Star size={13} fill="#c8991a" style={{ color: "#c8991a" }} />
            <span className="text-sm" style={{ fontFamily: "'DM Sans', sans-serif", color: "#c8991a" }}>
              {anime.rating}
            </span>
          </div>
          <span className="text-sm" style={{ color: "#7a8499", fontFamily: "'DM Sans', sans-serif" }}>{anime.year}</span>
          <span className="text-sm" style={{ color: "#7a8499", fontFamily: "'DM Sans', sans-serif" }}>
            {anime.episodes > 1 ? `${anime.episodes} Episodes` : "Film"}
          </span>
          <span className="text-sm" style={{ color: "#7a8499", fontFamily: "'DM Sans', sans-serif" }}>
            {anime.studio}
          </span>
          <div className="flex gap-2">
            {anime.genre.slice(0, 2).map((g) => (
              <span
                key={g}
                className="px-2 py-0.5 rounded text-xs"
                style={{
                  fontFamily: "'DM Sans', sans-serif",
                  background: "rgba(192,24,43,0.2)",
                  color: "#e06070",
                  border: "1px solid rgba(192,24,43,0.3)",
                }}
              >
                {g}
              </span>
            ))}
          </div>
        </div>

        {/* Synopsis */}
        <p
          className="mb-8 max-w-lg leading-relaxed"
          style={{
            fontFamily: "'DM Sans', sans-serif",
            color: "#b0b8c8",
            fontSize: "0.9rem",
            display: "-webkit-box",
            WebkitLineClamp: 3,
            WebkitBoxOrient: "vertical",
            overflow: "hidden",
          }}
        >
          {anime.synopsis}
        </p>

        {/* Action buttons */}
        <div className="flex items-center gap-4">
          <button
            onClick={() => onPlay(anime)}
            className="flex items-center gap-2 px-7 py-3 rounded transition-all duration-200 hover:scale-105 active:scale-95"
            style={{
              background: "#c0182b",
              color: "#fff",
              fontFamily: "'DM Sans', sans-serif",
              fontWeight: 600,
              letterSpacing: "0.05em",
            }}
          >
            <Play size={18} fill="white" />
            Watch Now
          </button>
          <button
            className="flex items-center gap-2 px-6 py-3 rounded transition-all duration-200 hover:scale-105"
            style={{
              background: "rgba(255,255,255,0.1)",
              color: "#e8eaf0",
              fontFamily: "'DM Sans', sans-serif",
              fontWeight: 500,
              border: "1px solid rgba(255,255,255,0.15)",
              backdropFilter: "blur(8px)",
            }}
          >
            <Plus size={18} />
            My List
          </button>
          <button
            className="p-3 rounded-full transition-all duration-200 hover:scale-105"
            style={{
              background: "rgba(255,255,255,0.08)",
              color: "#c8cdd8",
              border: "1px solid rgba(255,255,255,0.12)",
            }}
          >
            <Info size={18} />
          </button>
        </div>
      </div>

      {/* Carousel controls */}
      <div className="absolute right-8 bottom-32 md:bottom-24 flex flex-col items-end gap-3">
        <div className="flex gap-2">
          <button
            onClick={() => goTo((current - 1 + featured.length) % featured.length)}
            className="p-2 rounded-full transition hover:scale-105"
            style={{ background: "rgba(255,255,255,0.1)", color: "#fff", border: "1px solid rgba(255,255,255,0.15)" }}
          >
            <ChevronLeft size={16} />
          </button>
          <button
            onClick={() => goTo((current + 1) % featured.length)}
            className="p-2 rounded-full transition hover:scale-105"
            style={{ background: "rgba(255,255,255,0.1)", color: "#fff", border: "1px solid rgba(255,255,255,0.15)" }}
          >
            <ChevronRight size={16} />
          </button>
        </div>
        {/* Dots */}
        <div className="flex gap-1.5">
          {featured.map((_, i) => (
            <button
              key={i}
              onClick={() => goTo(i)}
              className="rounded-full transition-all duration-300"
              style={{
                width: i === current ? 20 : 6,
                height: 6,
                background: i === current ? "#c0182b" : "rgba(255,255,255,0.3)",
              }}
            />
          ))}
        </div>
      </div>

      {/* Bottom gradient into page */}
      <div
        className="absolute bottom-0 left-0 right-0 h-40 pointer-events-none"
        style={{ background: "linear-gradient(to bottom, transparent, #07090f)" }}
      />
    </div>
  );
}
