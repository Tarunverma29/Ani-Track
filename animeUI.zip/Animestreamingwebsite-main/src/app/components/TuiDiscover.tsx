import { useState } from "react";
import { TrackedAnime, WatchStatus, STATUS_COLORS, ALL_STATUSES, GENRES } from "./trackingData";

const MONO = "'JetBrains Mono', monospace";

// Extra browse items not yet in library
const BROWSE_ITEMS = [
  { id: 101, title: "Fullmetal Alchemist: Brotherhood", titleJp: "鋼の錬金術師", rating: 9.5, year: 2009, studio: "Bones", genre: ["Action","Drama","Fantasy"], type: "TV", season: "Spring 2009", totalEpisodes: 64, synopsis: "Two brothers search for the philosopher's stone to restore their bodies after a failed alchemical ritual.", image: "https://images.unsplash.com/photo-1586165877141-3dbcfc059283?w=400&h=200&fit=crop&auto=format" },
  { id: 102, title: "Vinland Saga", titleJp: "ヴィンランド・サガ", rating: 9.1, year: 2019, studio: "Wit Studio", genre: ["Action","Historical","Drama"], type: "TV", season: "Summer 2019", totalEpisodes: 48, synopsis: "A young Viking boy witnesses his father's murder and vows revenge across medieval Europe.", image: "https://images.unsplash.com/photo-1617541016107-b62971c6e27f?w=400&h=200&fit=crop&auto=format" },
  { id: 103, title: "Princess Mononoke", titleJp: "もののけ姫", rating: 9.1, year: 1997, studio: "Studio Ghibli", genre: ["Fantasy","Adventure","Drama"], type: "Movie", season: "–", totalEpisodes: 1, synopsis: "In war-torn medieval Japan, a young prince becomes involved in a conflict between forest gods and humans.", image: "https://images.unsplash.com/photo-1610129142564-79956dcecc7b?w=400&h=200&fit=crop&auto=format" },
  { id: 104, title: "Neon Genesis Evangelion", titleJp: "新世紀エヴァンゲリオン", rating: 9.0, year: 1995, studio: "Gainax", genre: ["Sci-Fi","Psychological","Action"], type: "TV", season: "Fall 1995", totalEpisodes: 26, synopsis: "Teenagers pilot colossal bio-machines called Evangelions to defend humanity against mysterious Angels.", image: "https://images.unsplash.com/photo-1534214526114-0ea4d47b04f2?w=400&h=200&fit=crop&auto=format" },
];

interface TuiDiscoverProps {
  library: TrackedAnime[];
  onAddToLibrary: (item: typeof BROWSE_ITEMS[0], status: WatchStatus) => void;
}

export function TuiDiscover({ library, onAddToLibrary }: TuiDiscoverProps) {
  const [query, setQuery] = useState("");
  const [genre, setGenre] = useState("All");
  const [addingId, setAddingId] = useState<number | null>(null);

  const inLibrary = (id: number) => library.some((a) => a.id === id);

  const items = [...BROWSE_ITEMS, ...library].filter((a, idx, arr) => arr.findIndex(b => b.id === a.id) === idx);

  const filtered = items.filter((a) => {
    const q = query.toLowerCase();
    const matchQ = !q || a.title.toLowerCase().includes(q) || a.titleJp.includes(q) || a.studio.toLowerCase().includes(q);
    const matchG = genre === "All" || a.genre.includes(genre);
    return matchQ && matchG;
  });

  return (
    <div className="flex-1 overflow-hidden flex flex-col" style={{ fontFamily: MONO }}>
      {/* Filter bar */}
      <div
        className="flex-shrink-0 flex items-center gap-4 px-4 border-b"
        style={{ height: 36, borderColor: "rgba(255,255,255,0.07)", background: "#0a0c10" }}
      >
        <span style={{ color: "#2a3545", fontSize: "0.6rem" }}>/</span>
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="search titles, studios..."
          className="bg-transparent outline-none text-xs flex-shrink-0"
          style={{ fontFamily: MONO, color: "#8a96a4", fontSize: "0.68rem", caretColor: "#b83040", width: 200 }}
          autoFocus
        />
        <div className="h-4 w-px" style={{ background: "rgba(255,255,255,0.07)" }} />
        <div className="flex items-center gap-1 overflow-x-auto">
          {GENRES.slice(0, 8).map((g) => (
            <button
              key={g}
              onClick={() => setGenre(g)}
              className="flex-shrink-0 px-2 py-0.5"
              style={{
                fontFamily: MONO,
                fontSize: "0.58rem",
                letterSpacing: "0.06em",
                color: genre === g ? "#c8d0da" : "#3d4e62",
                background: genre === g ? "#111520" : "transparent",
                border: `1px solid ${genre === g ? "rgba(255,255,255,0.1)" : "transparent"}`,
                cursor: "pointer",
              }}
            >
              {g.toUpperCase()}
            </button>
          ))}
        </div>
        <div className="flex-1" />
        <span style={{ color: "#2a3545", fontSize: "0.6rem" }}>{filtered.length} results</span>
      </div>

      {/* Column headers */}
      <div
        className="flex-shrink-0 flex items-center border-b px-4"
        style={{ height: 26, borderColor: "rgba(255,255,255,0.07)", background: "#0a0c10" }}
      >
        <div style={{ flex: 1, color: "#3d4e62", fontSize: "0.6rem", letterSpacing: "0.08em" }}>TITLE</div>
        <div style={{ width: 80, color: "#3d4e62", fontSize: "0.6rem", letterSpacing: "0.08em" }}>STUDIO</div>
        <div style={{ width: 48, color: "#3d4e62", fontSize: "0.6rem", letterSpacing: "0.08em", textAlign: "right" }}>EP</div>
        <div style={{ width: 64, color: "#3d4e62", fontSize: "0.6rem", letterSpacing: "0.08em", textAlign: "right" }}>RATING</div>
        <div style={{ width: 48, color: "#3d4e62", fontSize: "0.6rem", letterSpacing: "0.08em", textAlign: "right" }}>YEAR</div>
        <div style={{ width: 120 }} />
      </div>

      {/* Results */}
      <div className="flex-1 overflow-y-auto">
        {filtered.map((a) => {
          const inLib = inLibrary(a.id);
          const showing = addingId === a.id;
          return (
            <div
              key={a.id}
              className="flex items-center px-4 border-b group"
              style={{
                height: 36,
                borderColor: "rgba(255,255,255,0.04)",
                background: showing ? "#111520" : "transparent",
              }}
            >
              <div style={{ flex: 1, overflow: "hidden", paddingRight: 12 }}>
                <div className="flex items-baseline gap-2 overflow-hidden">
                  <span className="truncate" style={{ color: "#8a96a4", fontSize: "0.72rem" }}>{a.title}</span>
                  <span style={{ fontFamily: "'Noto Sans JP', sans-serif", color: "#2a3545", fontSize: "0.65rem", flexShrink: 0 }}>{a.titleJp}</span>
                </div>
              </div>
              <div style={{ width: 80, color: "#3d4e62", fontSize: "0.6rem" }} className="truncate">{a.studio}</div>
              <div className="tabular-nums" style={{ width: 48, color: "#3d4e62", fontSize: "0.6rem", textAlign: "right" }}>
                {a.totalEpisodes}
              </div>
              <div className="tabular-nums" style={{ width: 64, color: "#c8991a", fontSize: "0.68rem", textAlign: "right", fontWeight: 600 }}>
                {a.rating}
              </div>
              <div className="tabular-nums" style={{ width: 48, color: "#3d4e62", fontSize: "0.6rem", textAlign: "right" }}>
                {a.year}
              </div>
              <div style={{ width: 120, display: "flex", justifyContent: "flex-end" }}>
                {inLib ? (
                  <span style={{ color: "#4c7a50", fontSize: "0.58rem", letterSpacing: "0.08em" }}>IN LIBRARY</span>
                ) : showing ? (
                  <div className="flex gap-1">
                    {(["watching", "planning"] as WatchStatus[]).map((s) => (
                      <button
                        key={s}
                        onClick={() => { onAddToLibrary(a as any, s); setAddingId(null); }}
                        style={{
                          fontFamily: MONO,
                          fontSize: "0.55rem",
                          background: STATUS_COLORS[s],
                          color: "#0a0c10",
                          border: "none",
                          padding: "1px 6px",
                          cursor: "pointer",
                          letterSpacing: "0.05em",
                        }}
                      >
                        {s.toUpperCase()}
                      </button>
                    ))}
                    <button
                      onClick={() => setAddingId(null)}
                      style={{ fontFamily: MONO, fontSize: "0.55rem", color: "#3d4e62", background: "transparent", border: "none", cursor: "pointer" }}
                    >
                      esc
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setAddingId(a.id)}
                    className="opacity-0 group-hover:opacity-100 transition-opacity"
                    style={{
                      fontFamily: MONO,
                      fontSize: "0.58rem",
                      color: "#3a7a8c",
                      background: "transparent",
                      border: "1px solid rgba(58,122,140,0.3)",
                      padding: "1px 8px",
                      cursor: "pointer",
                      letterSpacing: "0.06em",
                    }}
                  >
                    + ADD
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
