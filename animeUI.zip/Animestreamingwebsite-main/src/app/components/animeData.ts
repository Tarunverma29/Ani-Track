export interface Anime {
  id: number;
  title: string;
  titleJp: string;
  genre: string[];
  rating: number;
  year: number;
  episodes: number;
  image: string;
  banner?: string;
  synopsis: string;
  studio: string;
  progress?: number;
  isNew?: boolean;
  isTrending?: boolean;
}

export const animeList: Anime[] = [
  {
    id: 1,
    title: "Demon Slayer",
    titleJp: "鬼滅の刃",
    genre: ["Action", "Fantasy", "Dark"],
    rating: 9.2,
    year: 2019,
    episodes: 44,
    image: "https://images.unsplash.com/photo-1597839219216-a773cb2473e4?w=400&h=560&fit=crop&auto=format",
    banner: "https://images.unsplash.com/photo-1601042879364-f3947d3f9c16?w=1920&h=1080&fit=crop&auto=format",
    synopsis: "A young boy becomes a demon slayer after his family is slaughtered and his sister is turned into a demon. A breathtaking journey through a world of darkness and beauty.",
    studio: "ufotable",
    isTrending: true,
  },
  {
    id: 2,
    title: "Attack on Titan",
    titleJp: "進撃の巨人",
    genre: ["Action", "Drama", "Horror"],
    rating: 9.4,
    year: 2013,
    episodes: 87,
    image: "https://images.unsplash.com/photo-1491466424936-e304919aada7?w=400&h=560&fit=crop&auto=format",
    banner: "https://images.unsplash.com/photo-1491466424936-e304919aada7?w=1920&h=1080&fit=crop&auto=format",
    synopsis: "Humanity's last survivors cower behind colossal walls as titans devour them at will. One boy's rage against these monsters will reshape the world.",
    studio: "MAPPA",
    isTrending: true,
  },
  {
    id: 3,
    title: "Jujutsu Kaisen",
    titleJp: "呪術廻戦",
    genre: ["Action", "Supernatural", "Horror"],
    rating: 8.9,
    year: 2020,
    episodes: 47,
    image: "https://images.unsplash.com/photo-1573455494060-c5595004fb6c?w=400&h=560&fit=crop&auto=format",
    banner: "https://images.unsplash.com/photo-1573455494060-c5595004fb6c?w=1920&h=1080&fit=crop&auto=format",
    synopsis: "A boy swallows a cursed talisman and becomes host to a powerful demon. He joins a secret organization of sorcerers to find and destroy the demon's scattered remains.",
    studio: "MAPPA",
    isNew: true,
  },
  {
    id: 4,
    title: "Your Name",
    titleJp: "君の名は。",
    genre: ["Romance", "Fantasy", "Drama"],
    rating: 9.1,
    year: 2016,
    episodes: 1,
    image: "https://images.unsplash.com/photo-1680011810663-7c825cafbbda?w=400&h=560&fit=crop&auto=format",
    banner: "https://images.unsplash.com/photo-1680011810663-7c825cafbbda?w=1920&h=1080&fit=crop&auto=format",
    synopsis: "Two teenagers share a profound, magical connection upon discovering they are swapping bodies. When the connection suddenly breaks, they set out to find each other.",
    studio: "CoMix Wave Films",
  },
  {
    id: 5,
    title: "Neon Genesis Evangelion",
    titleJp: "新世紀エヴァンゲリオン",
    genre: ["Sci-Fi", "Psychological", "Action"],
    rating: 9.0,
    year: 1995,
    episodes: 26,
    image: "https://images.unsplash.com/photo-1534214526114-0ea4d47b04f2?w=400&h=560&fit=crop&auto=format",
    banner: "https://images.unsplash.com/photo-1534214526114-0ea4d47b04f2?w=1920&h=1080&fit=crop&auto=format",
    synopsis: "In a post-apocalyptic world, teenagers pilot colossal bio-machines called Evangelions to defend humanity against mysterious beings known as Angels.",
    studio: "Gainax",
    progress: 68,
  },
  {
    id: 6,
    title: "Spirited Away",
    titleJp: "千と千尋の神隠し",
    genre: ["Fantasy", "Adventure", "Family"],
    rating: 9.3,
    year: 2001,
    episodes: 1,
    image: "https://images.unsplash.com/photo-1564284369929-026ba231f89b?w=400&h=560&fit=crop&auto=format",
    banner: "https://images.unsplash.com/photo-1564284369929-026ba231f89b?w=1920&h=1080&fit=crop&auto=format",
    synopsis: "A young girl wanders into a mysterious spirit world and must work to free herself and her parents who have been turned into pigs.",
    studio: "Studio Ghibli",
  },
  {
    id: 7,
    title: "Cowboy Bebop",
    titleJp: "カウボーイビバップ",
    genre: ["Sci-Fi", "Action", "Mystery"],
    rating: 9.0,
    year: 1998,
    episodes: 26,
    image: "https://images.unsplash.com/photo-1475070929565-c985b496cb9f?w=400&h=560&fit=crop&auto=format",
    banner: "https://images.unsplash.com/photo-1475070929565-c985b496cb9f?w=1920&h=1080&fit=crop&auto=format",
    synopsis: "A ragtag group of bounty hunters chase criminals across the solar system while haunted by their troubled pasts. Jazz, blues, and existential dread in space.",
    studio: "Sunrise",
    progress: 42,
  },
  {
    id: 8,
    title: "Fullmetal Alchemist",
    titleJp: "鋼の錬金術師",
    genre: ["Action", "Drama", "Fantasy"],
    rating: 9.5,
    year: 2009,
    episodes: 64,
    image: "https://images.unsplash.com/photo-1586165877141-3dbcfc059283?w=400&h=560&fit=crop&auto=format",
    banner: "https://images.unsplash.com/photo-1586165877141-3dbcfc059283?w=1920&h=1080&fit=crop&auto=format",
    synopsis: "Two brothers search for the philosopher's stone to restore their bodies after a failed alchemical ritual. What they discover will shake the very foundations of the world.",
    studio: "Bones",
    isNew: false,
  },
  {
    id: 9,
    title: "Death Note",
    titleJp: "デスノート",
    genre: ["Thriller", "Psychological", "Mystery"],
    rating: 9.0,
    year: 2006,
    episodes: 37,
    image: "https://images.unsplash.com/photo-1704050929730-65753014c435?w=400&h=560&fit=crop&auto=format",
    banner: "https://images.unsplash.com/photo-1704050929730-65753014c435?w=1920&h=1080&fit=crop&auto=format",
    synopsis: "A genius high school student discovers a supernatural notebook that can kill anyone whose name is written in it. He embarks on a mission to cleanse the world of evil.",
    studio: "Madhouse",
    progress: 89,
  },
  {
    id: 10,
    title: "Princess Mononoke",
    titleJp: "もののけ姫",
    genre: ["Fantasy", "Adventure", "Drama"],
    rating: 9.1,
    year: 1997,
    episodes: 1,
    image: "https://images.unsplash.com/photo-1610129142564-79956dcecc7b?w=400&h=560&fit=crop&auto=format",
    banner: "https://images.unsplash.com/photo-1610129142564-79956dcecc7b?w=1920&h=1080&fit=crop&auto=format",
    synopsis: "In war-torn medieval Japan, a young prince becomes involved in a conflict between forest gods and humans consuming their land.",
    studio: "Studio Ghibli",
    isNew: true,
  },
  {
    id: 11,
    title: "One Punch Man",
    titleJp: "ワンパンマン",
    genre: ["Action", "Comedy", "Superhero"],
    rating: 8.8,
    year: 2015,
    episodes: 24,
    image: "https://images.unsplash.com/photo-1616265350912-9ed401ac47ac?w=400&h=560&fit=crop&auto=format",
    banner: "https://images.unsplash.com/photo-1616265350912-9ed401ac47ac?w=1920&h=1080&fit=crop&auto=format",
    synopsis: "A hero who can defeat any enemy with a single punch grows bored of his overwhelming power and searches for someone who can give him a real challenge.",
    studio: "Madhouse",
    isNew: true,
  },
  {
    id: 12,
    title: "Vinland Saga",
    titleJp: "ヴィンランド・サガ",
    genre: ["Action", "Historical", "Drama"],
    rating: 9.1,
    year: 2019,
    episodes: 48,
    image: "https://images.unsplash.com/photo-1617541016107-b62971c6e27f?w=400&h=560&fit=crop&auto=format",
    banner: "https://images.unsplash.com/photo-1617541016107-b62971c6e27f?w=1920&h=1080&fit=crop&auto=format",
    synopsis: "A young Viking boy witnesses his father's murder and vows revenge, setting him on a brutal path across medieval Europe toward a land without war.",
    studio: "Wit Studio",
    progress: 25,
  },
];

export const genres = ["All", "Action", "Fantasy", "Romance", "Sci-Fi", "Horror", "Drama", "Thriller", "Comedy", "Mystery"];

export const featuredAnime = animeList[0];
export const trendingAnime = animeList.filter(a => a.isTrending || a.rating >= 9.0).slice(0, 8);
export const newReleases = animeList.filter(a => a.isNew || a.year >= 2019).slice(0, 6);
export const continueWatching = animeList.filter(a => a.progress !== undefined);
export const topRated = [...animeList].sort((a, b) => b.rating - a.rating).slice(0, 8);
