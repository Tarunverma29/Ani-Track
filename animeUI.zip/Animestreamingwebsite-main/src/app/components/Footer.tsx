import { Play } from "lucide-react";

export function Footer() {
  const links = {
    "Browse": ["Trending", "New Releases", "Top Rated", "Coming Soon", "All Anime"],
    "Genres": ["Action", "Romance", "Fantasy", "Sci-Fi", "Horror", "Drama"],
    "Account": ["My List", "History", "Settings", "Help Center", "Logout"],
    "Company": ["About", "Careers", "Press", "Privacy Policy", "Terms"],
  };

  return (
    <footer
      className="mt-16 border-t"
      style={{ borderColor: "rgba(255,255,255,0.07)", background: "#07090f" }}
    >
      <div className="max-w-screen-2xl mx-auto px-8 md:px-16 py-14">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8 mb-12">
          {/* Brand */}
          <div className="col-span-2 md:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-7 h-7 rounded flex items-center justify-center" style={{ background: "#c0182b" }}>
                <Play size={13} fill="white" className="text-white ml-0.5" />
              </div>
              <span
                className="text-white"
                style={{ fontFamily: "'Cinzel', serif", fontWeight: 700, fontSize: "1rem", letterSpacing: "0.12em" }}
              >
                AniStream
              </span>
            </div>
            <p style={{ fontFamily: "'Noto Sans JP', sans-serif", fontSize: "1.2rem", color: "#c8991a", marginBottom: 8 }}>
              アニメストリーム
            </p>
            <p style={{ fontFamily: "'DM Sans', sans-serif", fontSize: "0.8rem", color: "#7a8499", lineHeight: 1.6 }}>
              Your gateway to the finest Japanese animation. Stream thousands of titles in HD.
            </p>
          </div>

          {/* Link columns */}
          {Object.entries(links).map(([category, items]) => (
            <div key={category}>
              <h4
                className="mb-4"
                style={{ fontFamily: "'Cinzel', serif", fontSize: "0.75rem", color: "#c8cdd8", letterSpacing: "0.1em", textTransform: "uppercase" }}
              >
                {category}
              </h4>
              <ul className="flex flex-col gap-2.5">
                {items.map((item) => (
                  <li key={item}>
                    <a
                      href="#"
                      className="transition-colors hover:text-white"
                      style={{ fontFamily: "'DM Sans', sans-serif", fontSize: "0.82rem", color: "#7a8499" }}
                    >
                      {item}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom bar */}
        <div
          className="pt-8 border-t flex flex-col sm:flex-row justify-between items-center gap-4"
          style={{ borderColor: "rgba(255,255,255,0.07)" }}
        >
          <p style={{ fontFamily: "'DM Sans', sans-serif", fontSize: "0.75rem", color: "#4a5568" }}>
            © 2024 AniStream. All anime titles and artwork are property of their respective studios.
          </p>
          <div className="flex items-center gap-2">
            <span style={{ fontFamily: "'Noto Sans JP', sans-serif", fontSize: "0.7rem", color: "#4a5568" }}>
              日本のアニメ
            </span>
            <span className="w-1 h-1 rounded-full" style={{ background: "#c0182b" }} />
            <span style={{ fontFamily: "'DM Sans', sans-serif", fontSize: "0.7rem", color: "#4a5568" }}>
              Streaming Excellence
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}
